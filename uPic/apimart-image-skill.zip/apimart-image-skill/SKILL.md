---
name: apimart-image-skill
description: 通过 APIMart Images API（curl 风格）完成生成任务提交、任务查询和图片下载。适合批量小红书卡片、封面图和素材图工作流。
---

# APIMart Image Skill

这个 skill 提供一个可复用命令行工具，覆盖完整链路：

1. 提交生成任务
2. 轮询查询任务状态
3. 下载生成图片到本地

## 环境变量

默认从当前 shell 读取：

- `OPENAI_API_KEY`：你的 APIMart token
- `OPENAI_BASE_URL`：默认 `https://api.apimart.ai/v1`

如果你使用项目内环境文件，可先执行：

```bash
set -a; source .env.codex; set +a
```

## 命令

脚本路径：

`apimart-image-skill/scripts/apimart_image_task.py`

### 1) 仅提交任务

```bash
python3 apimart-image-skill/scripts/apimart_image_task.py generate \
  --prompt "星空下的古老城堡" \
  --size "16:9" \
  --resolution "2k" \
  --quality "high"
```

### 2) 查询任务状态

```bash
python3 apimart-image-skill/scripts/apimart_image_task.py status \
  --task-id task_xxx
```

### 3) 下载任务结果

```bash
python3 apimart-image-skill/scripts/apimart_image_task.py download \
  --task-id task_xxx \
  --out output.png
```

### 4) 短轮询（不长时间阻塞）

单次查询（用于外部循环）：

```bash
python3 apimart-image-skill/scripts/apimart_image_task.py poll \
  --task-id task_xxx \
  --once
```

短等待轮询（最多等 35 秒；完成时自动下载）：

```bash
python3 apimart-image-skill/scripts/apimart_image_task.py poll \
  --task-id task_xxx \
  --max-wait 35 \
  --poll-interval 3 \
  --out ./result.png
```

### 5) 一条命令跑完整链路

```bash
python3 apimart-image-skill/scripts/apimart_image_task.py run \
  --prompt "小红书封面：Claude Code 最近更新了啥？" \
  --size "3:4" \
  --resolution "2k" \
  --quality "high" \
  --out ./xhs_claude_code_cards_ai/card_1_from_skill.png
```

## 输出

- `generate`：输出 `task_id`
- `status`：输出当前状态 JSON
- `download`：输出本地文件路径
- `poll`：输出简要状态；完成时可自动下载
- `run`：输出 `task_id`、状态变化、最终下载路径
