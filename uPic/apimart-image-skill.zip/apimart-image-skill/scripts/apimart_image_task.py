#!/usr/bin/env python3
import argparse
import json
import os
import subprocess
import sys
import time
import urllib.parse
from pathlib import Path


def fail(msg: str, code: int = 1) -> None:
    print(f"Error: {msg}", file=sys.stderr)
    raise SystemExit(code)


def env_required(name: str) -> str:
    v = os.getenv(name, "").strip()
    if not v:
        fail(f"{name} is required")
    return v


def api_base() -> str:
    return os.getenv("OPENAI_BASE_URL", "https://api.apimart.ai/v1").rstrip("/")


def request_json(method: str, url: str, token: str, payload=None):
    cmd = [
        "curl",
        "--silent",
        "--show-error",
        "--request",
        method.upper(),
        "--url",
        url,
        "--header",
        f"Authorization: Bearer {token}",
        "--header",
        "Content-Type: application/json",
    ]
    if payload is not None:
        cmd.extend(["--data", json.dumps(payload, ensure_ascii=False)])

    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        fail(f"curl failed: {proc.stderr.strip() or proc.stdout.strip()}")
    body = proc.stdout.strip()
    if not body:
        fail("empty response body")
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        fail(f"non-json response: {body[:400]}")
    return {}


def submit_generate(args):
    token = env_required("OPENAI_API_KEY")
    payload = {
        "model": args.model,
        "prompt": args.prompt,
        "size": args.size,
        "resolution": args.resolution,
        "quality": args.quality,
        "n": args.n,
    }
    data = request_json("POST", f"{api_base()}/images/generations", token, payload)
    items = data.get("data") or []
    if not items or not items[0].get("task_id"):
        fail(f"unexpected response: {json.dumps(data, ensure_ascii=False)}")
    task_id = items[0]["task_id"]
    print(task_id)
    return task_id


def get_status(task_id: str):
    token = env_required("OPENAI_API_KEY")
    safe_id = urllib.parse.quote(task_id)
    data = request_json("GET", f"{api_base()}/tasks/{safe_id}", token, None)
    return data


def cmd_status(args):
    data = get_status(args.task_id)
    print(json.dumps(data, ensure_ascii=False, indent=2))


def extract_first_image_url(status_json):
    d = status_json.get("data") or {}
    result = d.get("result") or {}
    images = result.get("images") or []
    if not images:
        return None
    url_field = images[0].get("url")
    if isinstance(url_field, list) and url_field:
        return url_field[0]
    if isinstance(url_field, str):
        return url_field
    return None


def download_file(url: str, out_path: Path):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "curl",
        "--silent",
        "--show-error",
        "--location",
        "--output",
        str(out_path),
        url,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        fail(f"download failed: {proc.stderr.strip() or proc.stdout.strip()}")


def cmd_download(args):
    status_json = get_status(args.task_id)
    st = ((status_json.get("data") or {}).get("status") or "").lower()
    if st != "completed":
        fail(f"task not completed yet, current status: {st}")
    url = extract_first_image_url(status_json)
    if not url:
        fail("no image url found in completed task")
    out = Path(args.out).expanduser().resolve()
    download_file(url, out)
    print(str(out))


def cmd_run(args):
    task_id = submit_generate(args)
    print(f"submitted task_id={task_id}", file=sys.stderr)
    started = time.time()
    while True:
        status_json = get_status(task_id)
        d = status_json.get("data") or {}
        st = (d.get("status") or "").lower()
        prog = d.get("progress")
        print(f"status={st} progress={prog}", file=sys.stderr)
        if st == "completed":
            url = extract_first_image_url(status_json)
            if not url:
                fail("task completed but no image url")
            out = Path(args.out).expanduser().resolve()
            download_file(url, out)
            print(str(out))
            return
        if st in {"failed", "canceled"}:
            fail(json.dumps(status_json, ensure_ascii=False))
        if time.time() - started > args.timeout:
            fail(f"timeout waiting for task {task_id}")
        time.sleep(args.poll_interval)


def cmd_poll(args):
    started = time.time()
    while True:
        status_json = get_status(args.task_id)
        d = status_json.get("data") or {}
        st = (d.get("status") or "").lower()
        prog = d.get("progress")
        print(json.dumps({"task_id": args.task_id, "status": st, "progress": prog}, ensure_ascii=False))

        if st == "completed":
            if args.out:
                url = extract_first_image_url(status_json)
                if not url:
                    fail("task completed but no image url")
                out = Path(args.out).expanduser().resolve()
                download_file(url, out)
                print(str(out))
            return
        if st in {"failed", "canceled"}:
            fail(json.dumps(status_json, ensure_ascii=False))
        if args.once:
            raise SystemExit(2)
        if time.time() - started >= args.max_wait:
            raise SystemExit(2)
        time.sleep(args.poll_interval)


def build_parser():
    parser = argparse.ArgumentParser(description="APIMart image task helper")
    sp = parser.add_subparsers(dest="cmd", required=True)

    def add_generate_flags(x):
        x.add_argument("--model", default="gpt-image-2-official")
        x.add_argument("--prompt", required=True)
        x.add_argument("--size", default="3:4")
        x.add_argument("--resolution", default="2k")
        x.add_argument("--quality", default="high")
        x.add_argument("--n", type=int, default=1)

    g = sp.add_parser("generate", help="submit image generation task")
    add_generate_flags(g)
    g.set_defaults(func=submit_generate)

    s = sp.add_parser("status", help="query task status")
    s.add_argument("--task-id", required=True)
    s.set_defaults(func=cmd_status)

    d = sp.add_parser("download", help="download completed task image")
    d.add_argument("--task-id", required=True)
    d.add_argument("--out", required=True)
    d.set_defaults(func=cmd_download)

    r = sp.add_parser("run", help="submit, poll, and download in one command")
    add_generate_flags(r)
    r.add_argument("--out", required=True)
    r.add_argument("--poll-interval", type=int, default=3)
    r.add_argument("--timeout", type=int, default=600)
    r.set_defaults(func=cmd_run)

    poll_parser = sp.add_parser("poll", help="short polling; optionally download when completed")
    poll_parser.add_argument("--task-id", required=True)
    poll_parser.add_argument("--out")
    poll_parser.add_argument("--poll-interval", type=int, default=3)
    poll_parser.add_argument("--max-wait", type=int, default=35)
    poll_parser.add_argument("--once", action="store_true")
    poll_parser.set_defaults(func=cmd_poll)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
