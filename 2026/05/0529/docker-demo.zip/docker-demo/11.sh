构建与运行：
cd E:/APP/docker-demo
docker build -t docker-demo .
docker run --rm docker-demo